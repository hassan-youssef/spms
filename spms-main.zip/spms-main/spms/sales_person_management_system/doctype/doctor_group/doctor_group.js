// Copyright (c) 2022, aoai and contributors
// For license information, please see license.txt

frappe.ui.form.on('Doctor Group', {
	// refresh: function(frm) {

	// }
});
