# Copyright (c) 2022, aoai and Contributors
# See license.txt

# import frappe
import unittest

class TestDoctorGroup(unittest.TestCase):
	pass
